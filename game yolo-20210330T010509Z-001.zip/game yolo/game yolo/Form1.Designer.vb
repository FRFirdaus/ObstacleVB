﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.Finish = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Halang5 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Halang0 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Player = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Halang1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Halang4 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Halang3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Halang2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.LineShape1 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape2 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.btnLEFT = New System.Windows.Forms.Button()
        Me.btnRIGHT = New System.Windows.Forms.Button()
        Me.tmrHALANG1 = New System.Windows.Forms.Timer(Me.components)
        Me.tmrTOP = New System.Windows.Forms.Timer(Me.components)
        Me.tmrLEFT = New System.Windows.Forms.Timer(Me.components)
        Me.tmrRIGHT = New System.Windows.Forms.Timer(Me.components)
        Me.tmrBOTTOM = New System.Windows.Forms.Timer(Me.components)
        Me.lblMENANG = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblSCORE = New System.Windows.Forms.Label()
        Me.lblhasil = New System.Windows.Forms.Label()
        Me.cmbLEVEL = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Halang7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Halang6 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.SuspendLayout()
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.Halang6, Me.Halang7, Me.Finish, Me.Halang5, Me.Halang0, Me.Player, Me.Halang1, Me.Halang4, Me.Halang3, Me.Halang2, Me.LineShape1, Me.LineShape2})
        Me.ShapeContainer1.Size = New System.Drawing.Size(528, 253)
        Me.ShapeContainer1.TabIndex = 1
        Me.ShapeContainer1.TabStop = False
        '
        'Finish
        '
        Me.Finish.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.Finish.BorderWidth = 3
        Me.Finish.Location = New System.Drawing.Point(197, 724)
        Me.Finish.Name = "Finish"
        Me.Finish.Size = New System.Drawing.Size(173, 19)
        '
        'Halang5
        '
        Me.Halang5.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Halang5.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.Halang5.BorderWidth = 3
        Me.Halang5.Location = New System.Drawing.Point(253, 633)
        Me.Halang5.Name = "Halang5"
        Me.Halang5.Size = New System.Drawing.Size(116, 15)
        '
        'Halang0
        '
        Me.Halang0.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Halang0.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.Halang0.BorderWidth = 3
        Me.Halang0.Location = New System.Drawing.Point(197, 567)
        Me.Halang0.Name = "Halang0"
        Me.Halang0.Size = New System.Drawing.Size(131, 15)
        '
        'Player
        '
        Me.Player.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.Player.BorderWidth = 3
        Me.Player.Location = New System.Drawing.Point(276, 41)
        Me.Player.Name = "Player"
        Me.Player.Size = New System.Drawing.Size(11, 10)
        '
        'Halang1
        '
        Me.Halang1.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Halang1.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.Halang1.BorderWidth = 3
        Me.Halang1.Location = New System.Drawing.Point(254, 501)
        Me.Halang1.Name = "Halang1"
        Me.Halang1.Size = New System.Drawing.Size(115, 15)
        '
        'Halang4
        '
        Me.Halang4.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Halang4.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.Halang4.BorderWidth = 3
        Me.Halang4.Location = New System.Drawing.Point(198, 297)
        Me.Halang4.Name = "Halang4"
        Me.Halang4.Size = New System.Drawing.Size(130, 17)
        '
        'Halang3
        '
        Me.Halang3.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Halang3.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.Halang3.BorderWidth = 3
        Me.Halang3.Location = New System.Drawing.Point(260, 369)
        Me.Halang3.Name = "Halang3"
        Me.Halang3.Size = New System.Drawing.Size(109, 17)
        '
        'Halang2
        '
        Me.Halang2.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Halang2.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.Halang2.BorderWidth = 3
        Me.Halang2.Location = New System.Drawing.Point(197, 438)
        Me.Halang2.Name = "Halang2"
        Me.Halang2.Size = New System.Drawing.Size(133, 15)
        '
        'LineShape1
        '
        Me.LineShape1.BorderWidth = 3
        Me.LineShape1.Name = "LineShape1"
        Me.LineShape1.X1 = 198
        Me.LineShape1.X2 = 197
        Me.LineShape1.Y1 = -10
        Me.LineShape1.Y2 = 521
        '
        'LineShape2
        '
        Me.LineShape2.BorderWidth = 3
        Me.LineShape2.Name = "LineShape2"
        Me.LineShape2.X1 = 369
        Me.LineShape2.X2 = 369
        Me.LineShape2.Y1 = -8
        Me.LineShape2.Y2 = 519
        '
        'btnLEFT
        '
        Me.btnLEFT.Location = New System.Drawing.Point(230, 9)
        Me.btnLEFT.Name = "btnLEFT"
        Me.btnLEFT.Size = New System.Drawing.Size(48, 23)
        Me.btnLEFT.TabIndex = 2
        Me.btnLEFT.Text = "Left"
        Me.btnLEFT.UseVisualStyleBackColor = True
        '
        'btnRIGHT
        '
        Me.btnRIGHT.Location = New System.Drawing.Point(284, 9)
        Me.btnRIGHT.Name = "btnRIGHT"
        Me.btnRIGHT.Size = New System.Drawing.Size(48, 23)
        Me.btnRIGHT.TabIndex = 3
        Me.btnRIGHT.Text = "Right"
        Me.btnRIGHT.UseVisualStyleBackColor = True
        '
        'tmrHALANG1
        '
        Me.tmrHALANG1.Interval = 25
        '
        'tmrTOP
        '
        Me.tmrTOP.Interval = 10
        '
        'tmrLEFT
        '
        Me.tmrLEFT.Interval = 10
        '
        'tmrRIGHT
        '
        Me.tmrRIGHT.Interval = 10
        '
        'tmrBOTTOM
        '
        Me.tmrBOTTOM.Interval = 10
        '
        'lblMENANG
        '
        Me.lblMENANG.AutoSize = True
        Me.lblMENANG.Location = New System.Drawing.Point(225, 728)
        Me.lblMENANG.Name = "lblMENANG"
        Me.lblMENANG.Size = New System.Drawing.Size(121, 13)
        Me.lblMENANG.TabIndex = 5
        Me.lblMENANG.Text = "Selamat Anda Menang!!"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Monotype Corsiva", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(119, 67)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 33)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Score"
        '
        'lblSCORE
        '
        Me.lblSCORE.AutoSize = True
        Me.lblSCORE.Font = New System.Drawing.Font("Monotype Corsiva", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSCORE.Location = New System.Drawing.Point(150, 96)
        Me.lblSCORE.Name = "lblSCORE"
        Me.lblSCORE.Size = New System.Drawing.Size(28, 33)
        Me.lblSCORE.TabIndex = 7
        Me.lblSCORE.Text = "0"
        '
        'lblhasil
        '
        Me.lblhasil.AutoSize = True
        Me.lblhasil.Font = New System.Drawing.Font("Monotype Corsiva", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhasil.Location = New System.Drawing.Point(131, 129)
        Me.lblhasil.Name = "lblhasil"
        Me.lblhasil.Size = New System.Drawing.Size(47, 22)
        Me.lblhasil.TabIndex = 8
        Me.lblhasil.Text = "hasil"
        '
        'cmbLEVEL
        '
        Me.cmbLEVEL.FormattingEnabled = True
        Me.cmbLEVEL.Items.AddRange(New Object() {"Easy", "Hard"})
        Me.cmbLEVEL.Location = New System.Drawing.Point(88, 41)
        Me.cmbLEVEL.Name = "cmbLEVEL"
        Me.cmbLEVEL.Size = New System.Drawing.Size(46, 21)
        Me.cmbLEVEL.TabIndex = 9
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(38, 43)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(46, 16)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Level"
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(140, 41)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(48, 23)
        Me.btnOK.TabIndex = 11
        Me.btnOK.Text = "Go!!"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Monotype Corsiva", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(179, 28)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Pilih Level First!"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(0, 203)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(56, 50)
        Me.Button1.TabIndex = 13
        Me.Button1.Text = "?"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Halang7
        '
        Me.Halang7.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Halang7.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.Halang7.BorderWidth = 3
        Me.Halang7.Location = New System.Drawing.Point(260, 226)
        Me.Halang7.Name = "Halang7"
        Me.Halang7.Size = New System.Drawing.Size(109, 15)
        '
        'Halang6
        '
        Me.Halang6.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Halang6.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.Halang6.BorderWidth = 3
        Me.Halang6.Location = New System.Drawing.Point(197, 161)
        Me.Halang6.Name = "Halang6"
        Me.Halang6.Size = New System.Drawing.Size(120, 15)
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MintCream
        Me.ClientSize = New System.Drawing.Size(528, 253)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cmbLEVEL)
        Me.Controls.Add(Me.lblhasil)
        Me.Controls.Add(Me.lblSCORE)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblMENANG)
        Me.Controls.Add(Me.btnRIGHT)
        Me.Controls.Add(Me.btnLEFT)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnLEFT As System.Windows.Forms.Button
    Friend WithEvents btnRIGHT As System.Windows.Forms.Button
    Friend WithEvents tmrHALANG1 As System.Windows.Forms.Timer
    Friend WithEvents tmrTOP As System.Windows.Forms.Timer
    Friend WithEvents tmrLEFT As System.Windows.Forms.Timer
    Friend WithEvents tmrRIGHT As System.Windows.Forms.Timer
    Friend WithEvents tmrBOTTOM As System.Windows.Forms.Timer
    Friend WithEvents lblMENANG As System.Windows.Forms.Label
    Private WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Private WithEvents Player As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Private WithEvents Halang1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Private WithEvents Halang4 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Private WithEvents Halang3 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Private WithEvents Halang2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Private WithEvents LineShape1 As Microsoft.VisualBasic.PowerPacks.LineShape
    Private WithEvents LineShape2 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblSCORE As System.Windows.Forms.Label
    Friend WithEvents lblhasil As System.Windows.Forms.Label
    Private WithEvents Halang0 As PowerPacks.RectangleShape
    Private WithEvents Halang5 As PowerPacks.RectangleShape
    Friend WithEvents cmbLEVEL As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btnOK As Button
    Friend WithEvents Label3 As Label
    Private WithEvents Finish As PowerPacks.RectangleShape
    Friend WithEvents Button1 As Button
    Private WithEvents Halang6 As PowerPacks.RectangleShape
    Private WithEvents Halang7 As PowerPacks.RectangleShape
End Class
